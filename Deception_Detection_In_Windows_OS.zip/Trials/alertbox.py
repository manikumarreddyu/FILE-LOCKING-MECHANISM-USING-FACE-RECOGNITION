from tkinter import *
from tkinter import messagebox

#Import the library
from tkinter import *



messagebox.showinfo("showinfo", "Information")

messagebox.showwarning("showwarning", "Warning")

messagebox.showerror("showerror", "Error")

messagebox.askquestion("askquestion", "Are you sure?")

messagebox.askokcancel("askokcancel", "Want to continue?")

messagebox.askyesno("askyesno", "Find the value?")


messagebox.askretrycancel("askretrycancel", "Try again?")

root.mainloop()
