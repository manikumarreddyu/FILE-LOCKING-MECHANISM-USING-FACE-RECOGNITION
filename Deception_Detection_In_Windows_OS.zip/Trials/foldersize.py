# import module
import os

# assign size
size = 0

folders=[]

# assign folder path
#Folderpath = 'C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\Sample1'
rootdir = 'C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials'
for file in os.listdir(rootdir):
    d = os.path.join(rootdir, file)
    if os.path.isdir(d):
        #print(d)
        for path, dirs, files in os.walk(d):
            for f in files:
                fp = os.path.join(path, f)
                size += os.path.getsize(fp)
        #print(d+" "+"Folder size: " + str(size))
        folders.append({"path":d, "size":size})

#sort sub_folders by size
# reverse = True: returns largest to smallest
# reverse = False: returns smallest to largest
folders.sort(key=lambda filename: filename['size'], reverse=False)

for f in folders:
    print("#"*50)
    #print folder's name
    #print("folder name: " + f['name'])
    #print folder's path
    print("folder path: " + f['path'])
    #print folder's size
    print("folder size: " + str(f['size']))


