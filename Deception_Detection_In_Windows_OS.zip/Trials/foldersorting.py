import os
# base folder
base_dir = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials"
# Get all sub files
files = os.listdir(base_dir)

folders = []

for e in files:
    #join base folder's name with sub file
    filepath = os.path.join(base_dir, e)
    #check if the file is directory(folder)
    if os.path.isdir(filepath):
        #append the folder_name, folder_path & size to the folders list
        folders.append({"name":e, "path":filepath, "size":os.path.getsize(filepath)})


#sort sub_folders by size
# reverse = True: returns largest to smallest
# reverse = False: returns smallest to largest
folders.sort(key=lambda filename: filename['size'], reverse=True)

for f in folders:
    print("#"*50)
    #print folder's name
    print("folder name: " + f['name'])
    #print folder's path
    print("folder path: " + f['path'])
    #print folder's size
    print("folder size: " + str(f['size']))
