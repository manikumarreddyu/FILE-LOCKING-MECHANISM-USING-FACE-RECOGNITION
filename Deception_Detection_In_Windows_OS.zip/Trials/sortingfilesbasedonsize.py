import os
dir_name = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials"
# Get list of all files only in the given directory
list_of_files = filter(lambda x: os.path.isfile(os.path.join(dir_name, x)) and x.endswith('.jpg'),
       os.listdir(dir_name))
# Sort list of file names by size 
list_of_files = sorted( list_of_files,
                        key =  lambda x: os.stat(os.path.join(dir_name, x)).st_size)
# Iterate over sorted list of file names and 
# print them one by one along with size
for file_name in list_of_files:
    file_path = os.path.join(dir_name, file_name)
    file_size  = os.stat(file_path).st_size 
    print(file_size, ' -->', file_name)   
