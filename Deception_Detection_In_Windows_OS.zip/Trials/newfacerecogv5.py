import os
from os import listdir
import numpy as np
import cv2
from tkinter import *
from tkinter import messagebox
from gtts import gTTS
from playsound import playsound

detectors = {
   "face": "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\haarcascade_frontalface_default.xml",
   "eyes": "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\haarcascade_eye.xml",
   "smile": "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\haarcascade_smile.xml",
    }

# Classifies the path file as a cascade
facedetect = cv2.CascadeClassifier(detectors['face'])
eyedetect = cv2.CascadeClassifier(detectors['eyes'])
smiledetect = cv2.CascadeClassifier(detectors['smile'])

# assign size
size = 0

folders=[]

# assign folder path
#Folderpath = 'C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\Sample1'
rootdir = 'C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials'
for file in os.listdir(rootdir):
    d = os.path.join(rootdir, file)
    if os.path.isdir(d):
        print(d)
        for path, dirs, files in os.walk(d):
            for f in files:
                fp = os.path.join(path, f)
                size += os.path.getsize(fp)
        #print(d+" "+"Folder size: " + str(size))
        folders.append({"path":d, "size":size})

#sort sub_folders by size
# reverse = True: returns largest to smallest
# reverse = False: returns smallest to largest
folders.sort(key=lambda filename: filename['size'], reverse=False)

for f in folders:
    dir_name = f['path']
    #print("folder path: " + dir_name)
    list_of_files = filter(lambda x: os.path.isfile(os.path.join(dir_name, x)) and x.endswith('2.jpg'),
       os.listdir(dir_name))
 
    for file_name in list_of_files:
        #print(file_name)
        original = cv2.imread('C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\man.jpg')
        gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
        equalized = cv2.equalizeHist(gray)
        img = cv2.resize(original, (0,0), fx= 0.4, fy= 0.4)
        copy = img.copy()
        print(img.shape)
        # Face detection
        face = facedetect.detectMultiScale(img, scaleFactor=1.05, minNeighbors=5, minSize=(30, 30),
		flags=cv2.CASCADE_SCALE_IMAGE)
        print(face)

        #initialize variables

        minNeighbors_EYE = 10
        scaleFactor_EYE = 1.1
        minNeighbors_SMILE = 10
        scaleFactor_SMILE = 1.1
        
        # loop over the face bounding boxes
        for (fX, fY, fW, fH) in face:
            # extract the face area
            faceArea = img[fY:fY+ fH, fX:fX + fW]
            # apply eyes detection to the face Area
            upper_half_faceArea = img[fY:fY+ int(fH/2), fX:fX + fW]
            eyeBox = eyedetect.detectMultiScale(upper_half_faceArea, scaleFactor=scaleFactor_EYE, minNeighbors=minNeighbors_EYE,
                                                minSize=(15, 15), maxSize=(30,30), flags=cv2.CASCADE_SCALE_IMAGE)
            # apply smile detection to the face Area
            bottom_half_faceArea = img[fY+int(fH/2):fY+fH, fX:fX + fW]
            smileBox = smiledetect.detectMultiScale(
                bottom_half_faceArea, scaleFactor=scaleFactor_SMILE, minNeighbors=minNeighbors_SMILE,
                minSize=(15, 15), flags=cv2.CASCADE_SCALE_IMAGE)
            # loop over the eye bounding boxes
            for (eX, eY, eW, eH) in eyeBox:
                # draw the eye bounding box
                eyeA = (fX + eX, fY + eY)
                eyeB = (fX + eX + eW, fY + eY + eH)
                cv2.rectangle(img, eyeA, eyeB, (0, 0, 255), 2)
            #ret, thresh1 = cv2.threshold(eyeBox,127,255,cv2.THRESH_BINARY)
            # loop over the smile bounding boxes
            for (sX, sY, sW, sH) in smileBox:
            # draw the smile bounding box
                ptA = (fX + sX, fY + int(fH/2)+ sY)
                ptB = (fX + sX + sW, fY + int(fH/2) + sY + sH)
                cv2.rectangle(img, ptA, ptB, (255, 0, 0), 2)
            # draw the face bounding box on the frame
            cv2.rectangle(img, (fX, fY), (fX + fW, fY + fH),(0, 255, 0), 2)
        eyes = []
        for i in eyeBox:
            crop_img = copy[fY + i[1]:fY + i[1]+ i[3], fX + i[0]:fX + i[0] + i[2]]
            gray_crop = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
            ret, thresh1 = cv2.threshold(gray_crop,127,255,cv2.THRESH_BINARY_INV)
            white = np.sum(thresh1 == 255)
            eyes.append(white)
            white_percentage = white/thresh1.size
            #print("The white pixels are: ", white)
            #print("The percentage of white pixels: ", "{:.0%}".format(white_percentage))
            #cv2.imshow("cropped", thresh1)
            #cv2.waitKey(0)
        for i in smileBox:
            crop_img = copy[fY + int(fH/2) + i[1]:fY + int(fH/2) + i[1]+ i[3], fX + i[0]:fX + i[0] + i[2]]
            smile_height = i[3]
            #print("The smile's height is: ", smile_height)
            size = crop_img.size
            #print("The smile size is: ", size)
            gray_crop = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
            ret, thresh1 = cv2.threshold(gray_crop,127,255,cv2.THRESH_BINARY_INV)
            #cv2.imshow("cropped", thresh1)
            #cv2.waitKey(0)
        cv2.imshow('Neutral image', img)
        cv2.waitKey(0)
        list_of_files1 = filter(lambda x: os.path.isfile(os.path.join(dir_name, x)) and x.endswith('1.jpg'),
       os.listdir(dir_name))
        for file_name in list_of_files1:
            print(file_name)
            #original1 = cv2.imread('C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\Sample2\\man.jpg')
            original1 = cv2.imread('C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\Sample2\\man2.jpg')
            print(original1)
            gray = cv2.cvtColor(original1, cv2.COLOR_BGR2GRAY)
            equalized = cv2.equalizeHist(gray)
            img2 = cv2.resize(original1, (0,0), fx= 0.4, fy= 0.4)
            copy = img2.copy()
            #print(img2.shape)
            # Face detection
            face = facedetect.detectMultiScale(
		img2, scaleFactor=1.05, minNeighbors=5, minSize=(30, 30),
		flags=cv2.CASCADE_SCALE_IMAGE)

            #initialize variables
            minNeighbors_EYE = 10
            scaleFactor_EYE = 1.1
            minNeighbors_SMILE = 10
            scaleFactor_SMILE = 1.1

            # loop over the face bounding boxes
            for (fX, fY, fW, fH) in face:
                # extract the face area
                faceArea = img2[fY:fY+ fH, fX:fX + fW]
                # apply eyes detection to the face Area
                upper_half_faceArea = img2[fY:fY+ int(fH/2), fX:fX + fW]
                eyeBox = eyedetect.detectMultiScale(
                    upper_half_faceArea, scaleFactor=scaleFactor_EYE, minNeighbors=minNeighbors_EYE,
                    minSize=(15, 15), flags=cv2.CASCADE_SCALE_IMAGE)
                # apply smile detection to the face Area
                bottom_half_faceArea = img2[fY+int(fH/2):fY+fH, fX:fX + fW]
                smileBox = smiledetect.detectMultiScale(
                    bottom_half_faceArea, scaleFactor=scaleFactor_SMILE, minNeighbors=minNeighbors_SMILE,
                    minSize=(15, 15), flags=cv2.CASCADE_SCALE_IMAGE)
                # loop over the eye bounding boxes
                for (eX, eY, eW, eH) in eyeBox:
                    # draw the eye bounding box
                    eyeA = (fX + eX, fY + eY)
                    eyeB = (fX + eX + eW, fY + eY + eH)
                    cv2.rectangle(img2, eyeA, eyeB, (0, 0, 255), 2)
                #ret, thresh1 = cv2.threshold(eyeBox,127,255,cv2.THRESH_BINARY)

                # loop over the smile bounding boxes
                for (sX, sY, sW, sH) in smileBox:
                    # draw the smile bounding box
                    ptA = (fX + sX, fY + int(fH/2)+ sY)
                    ptB = (fX + sX + sW, fY + int(fH/2) + sY + sH)
                    cv2.rectangle(img2, ptA, ptB, (255, 0, 0), 2)
                # draw the face bounding box on the frame
                cv2.rectangle(img2, (fX, fY), (fX + fW, fY + fH),(0, 255, 0), 2)
                eyes2=[]
                for i in eyeBox:
                    crop_img = copy[fY + i[1]:fY + i[1]+ i[3], fX + i[0]:fX + i[0] + i[2]]
                    gray_crop = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
                    ret, thresh1 = cv2.threshold(gray_crop,127,255,cv2.THRESH_BINARY_INV)
                    white = np.sum(thresh1 == 255)
                    eyes2.append(white)
                    white_percentage = white/thresh1.size
                    #print("The white pixels are: ", white)
                    #print("The percentage of white pixels: ", "{:.0%}".format(white_percentage))
                    #cv2.imshow("cropped", thresh1)
                    #cv2.waitKey(0)
            if len(eyes) == 2 and len(eyes2) == 1:
                eyes2.append(0)
            if len(eyes2) == 2 and len(eyes) == 1:
                eyes.append(0)
            for i in smileBox:
                crop_img = copy[fY + int(fH/2) + i[1]:fY + int(fH/2) + i[1]+ i[3], fX + i[0]:fX + i[0] + i[2]]
                smile_height = i[3]
                #print("The smile's height is: ", smile_height)
                size2 = crop_img.size
                #print("The smile size is: ", size2)
                gray_crop = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
                ret, thresh1 = cv2.threshold(gray_crop,127,255,cv2.THRESH_BINARY_INV)
                #cv2.imshow("cropped", thresh1)
                #cv2.waitKey(0)
            cv2.imshow('Image with expression', img2)
            cv2.waitKey(0)
            if size2>size:
                messagebox.showinfo("Result", "When the person is lying his smile is bigger")
                #print('when the person is lying his smile is bigger')
                message = "When the person is lying his smile is bigger"
            else:
                messagebox.showinfo("Result", "When the person is not lying his smile is smaller")
                #print('when the person is not lying his smile is smaller')
                message = "When the person is not lying his smile is smaller"

            # Create a TTS object
            tts = gTTS(message)

            # Save the generated audio file
            tts.save('voice_message.mp3')

            # Play the audio file
            playsound('voice_message.mp3')
            
            #ASSUMPTION: BOTH EYES ARE THE SAME
            if eyes[0]>eyes2[0]:
                messagebox.showinfo("Result", "When the person is lying his eyes are more open")
                #print('when the person is lying his eyes are more open')
                message = "When the person is lying his eyes are more open"
            else:
                messagebox.showinfo("Result", "When the person is not lying his eyes are less open/squinting")
                #print('when the person is not lying his eyes are less open/squinting')
                message = "When the person is not lying his eyes are less open/squinting"

            # Create a TTS object
            tts = gTTS(message)

            # Save the generated audio file
            tts.save('voice_message.mp3')

            # Play the audio file
            playsound('voice_message.mp3')
            together = np.hstack((img, img2))
            cv2.imshow('together', together)
            cv2.waitKey(0)
        
