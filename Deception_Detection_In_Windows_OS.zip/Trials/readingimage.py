import sys

import cv2
import numpy as np

# Load and display an image -- 'forest.jpg'
input_file = sys.argv[0]
img = cv2.imread(input_file)

cv2.imshow('Original', img)
