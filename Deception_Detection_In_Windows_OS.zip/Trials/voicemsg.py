from gtts import gTTS
from playsound import playsound

message = "The person is saying the truth"

# Create a TTS object
tts = gTTS(message)

# Save the generated audio file
tts.save('voice_message.mp3')

# Play the audio file
playsound('voice_message.mp3')
