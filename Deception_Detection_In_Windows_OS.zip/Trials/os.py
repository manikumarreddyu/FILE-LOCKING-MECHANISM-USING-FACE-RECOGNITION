import os
from os import listdir
import numpy as np
import cv2

# get the path/directory
face_detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_detector = cv2.CascadeClassifier('haarcascade_eye.xml')
dir_name = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials"

# Get list of all files only in the given directory
list_of_files = filter(lambda x: os.path.isfile(os.path.join(dir_name, x)) and x.endswith('.jpg'),
       os.listdir(dir_name))

# Sort list of file names by size 
list_of_files = sorted( list_of_files,
                        key =  lambda x: os.stat(os.path.join(dir_name, x)).st_size)

# Iterate over sorted list of file names and 
# print them one by one along with size
for file_name in list_of_files:
    
        file_size  = os.stat(file_name).st_size 
        print(file_size, ' -->', file_name)   
        img = cv2.imread(file_name)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_detector.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
            cv2.imshow('img',img)
            cv2.waitKey(0)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = img[y:y+h, x:x+w]
            eyes = eye_detector.detectMultiScale(roi_gray)
            for (ex,ey,ew,eh) in eyes:
                cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
                cv2.imshow('img',img)
                cv2.waitKey(0)
        
        cv2.destroyAllWindows()