rom sklearn import preprocessing                                         
engine = pyttsx3.init('sapi5')                                            # Defining the speech rate, type of voice etc.
voices = engine.getProperty('voices')
rate = engine.getProperty('rate')
engine.setProperty('rate', rate-20)
engine.setProperty('voice',voices[0].id)


def speak(audio):                                                         # Defining a speak function. We can call this function when we want to make our program to speak something.
	engine.say(audio) 
	engine.runAndWait()

speak("Sir according to the data that you provided to me. The prediction I have made is " + prediction