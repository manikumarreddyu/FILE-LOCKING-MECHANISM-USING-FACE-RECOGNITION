from gtts import gTTS
import pygame

message = "Hello, world!"  # The message you want to convert to speech

# Create a TTS object
tts = gTTS(message)

# Save the generated audio file
audio_file = "voice_message.mp3"
tts.save(audio_file)

# Initialize the audio playback
pygame.mixer.init()

# Load the audio file
pygame.mixer.music.load(audio_file)

# Play the audio file
pygame.mixer.music.play()

# Wait until the audio finishes playing
while pygame.mixer.music.get_busy():
    continue

# Quit pygame and clean up resources
pygame.mixer.quit()
