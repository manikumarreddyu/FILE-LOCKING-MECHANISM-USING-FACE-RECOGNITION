import cv2
import os
import numpy as np
import shutil
import tkinter as tk
from tkinter import messagebox
import ctypes

# Set the name of the person
person_name = "authorized_user"

# Set the path to the dataset folder
dataset_path = "dataset/" + person_name

# Create the dataset folder if it doesn't exist
if not os.path.exists(dataset_path):
    os.makedirs(dataset_path)

# Initialize the webcam
cap = cv2.VideoCapture(0)

# Set the initial face counter
face_counter = 0

# Loop until the desired number of facial images is captured
while face_counter < 100:
    # Read the frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    # Iterate over the detected faces
    for (x, y, w, h) in faces:
        # Draw a rectangle around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Save the face image to the dataset folder
        face_image = gray[y:y + h, x:x + w]
        face_filename = dataset_path + "/face_" + str(face_counter) + ".jpg"
        cv2.imwrite(face_filename, face_image)

        # Increment the face counter
        face_counter += 1

    # Display the frame
    cv2.imshow("Capture", frame)

    # Check for key press events
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
cap.release()
cv2.destroyAllWindows()
# Set the path to the dataset folder
dataset_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dataset"

# Function to load the training data
def load_training_data():
    faces = []
    labels = []
    label_ids = {}

    # Iterate over the subfolders in the dataset folder
    for root, dirs, files in os.walk(dataset_path):
        for dir_name in dirs:
            # Assign a label ID to each subfolder
            label_id = len(label_ids)
            label_ids[dir_name] = label_id

            # Get the path to the subfolder
            subfolder_path = os.path.join(root, dir_name)

            # Iterate over the image files in the subfolder
            for filename in os.listdir(subfolder_path):
                image_path = os.path.join(subfolder_path, filename)
                # Read the image file
                image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

                # Append the image and label to the training data
                faces.append(image)
                labels.append(label_id)

    return faces, labels, label_ids

# Load the training data
faces, labels, label_ids = load_training_data()

# Create the face recognition model
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# Train the face recognition model
face_recognizer.train(faces, np.array(labels))

# Save the trained model to a file
model_path = "face_model.yml"
face_recognizer.save(model_path)

messagebox.showinfo("Message", "Face model trained")


# Function to handle button click
def handle_button_click():
    global user_input
    user_input = entry.get()
    if user_input:
        messagebox.showinfo("User Input", f"You entered: {user_input}")
        # Check if the specified folder exists
        folder_path = os.path.join(os.getcwd(), user_input)
        if os.path.exists(folder_path):
            # Perform the desired operations on the existing folder
            messagebox.showinfo("Message", "Folder exists!")
            # Load the pre-trained face recognition model
            face_recognizer = cv2.face.LBPHFaceRecognizer_create()

            # Load the trained model from file
            face_recognizer.read("face_model.yml")

            # Set the path to the folder you want to lock
            folder_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\"+user_input
            print(folder_path)

            # Initialize the webcam
            cap = cv2.VideoCapture(0)

            # Loop indefinitely
            while True:
                # Read the frame from the webcam
                ret, frame = cap.read()

                # Convert the frame to grayscale
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                # Detect faces in the frame
                face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

                # Flag to check if an authorized user is detected
                authorized_user_detected = False

                # Iterate over the detected faces
                for (x, y, w, h) in faces:
                    # Recognize the face
                    face_image = gray[y:y + h, x:x + w]
                    label_id, confidence = face_recognizer.predict(face_image)

                    # Check if the face matches the authorized user
                    if confidence < 70:
                        authorized_user_detected = True
                        break
            # If an authorized user is not detected, lock the folder
            if not authorized_user_detected:
                # Set the lock attribute for the folder (making it hidden and read-only)
                def lock_folder(path):
                    try:
                        # Set the folder as hidden
                        attributes = ctypes.windll.kernel32.GetFileAttributesW(path)
                        ctypes.windll.kernel32.SetFileAttributesW(path, attributes + 2)

                        # Set the folder as read-only
                        os.chmod(path, 0o400)

                        messagebox.showinfo("Message", "Folder locked successfully")
                    except Exception as e:
                        messagebox.showinfo("Message", "Failed to lock folder")
                # Call the function to lock the folder
                lock_folder(folder_path)
                
            else:
                # Set the unlock attribute for the folder (removing hidden and read-only attributes)
                def unlock_folder(path):
                    try:
                        # Remove the hidden attribute from the folder
                        attributes = ctypes.windll.kernel32.GetFileAttributesW(path)
                        ctypes.windll.kernel32.SetFileAttributesW(path, attributes - 2)
                        # Set the folder as writable
                        os.chmod(path, 0o600)
                        messagebox.showinfo("Message", "Folder unlocked successfully!")
                    except Exception as e:
                        messagebox.showinfo("Message", "Failed to unlock folder")
                # Call the function to unlock the folder
                unlock_folder(folder_path)
                break
            # Display the frame
            cv2.imshow("Face Recognition", frame)
            # Check for key press events
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            # Release the webcam and close the window
            cap.release()
            cv2.destroyAllWindows()
        else:
            messagebox.showinfo("Message", "This folder doesn not exist")
    else:
        messagebox.showerror("Error", "Please enter valid filename.")

# Create the main window
window = tk.Tk()
window.title("User Input")

# Create a label
label = tk.Label(window, text="Enter folder name:")
label.pack(pady=10)

# Create an entry field
entry = tk.Entry(window, width=30)
entry.pack()

# Create a button
button = tk.Button(window, text="Submit", command=handle_button_click)
button.pack(pady=10)

# Run the main window loop
window.mainloop()
