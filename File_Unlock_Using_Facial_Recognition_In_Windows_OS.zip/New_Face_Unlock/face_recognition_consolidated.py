import cv2
import os
import numpy as np
import shutil
import tkinter as tk
from tkinter import messagebox

# Set the name of the person
person_name = "authorized_user"

# Set the path to the dataset folder
dataset_path = "dataset/" + person_name

# Create the dataset folder if it doesn't exist
if not os.path.exists(dataset_path):
    os.makedirs(dataset_path)

# Initialize the webcam
cap = cv2.VideoCapture(0)

# Set the initial face counter
face_counter = 0

# Loop until the desired number of facial images is captured
while face_counter < 100:
    # Read the frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    # Iterate over the detected faces
    for (x, y, w, h) in faces:
        # Draw a rectangle around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Save the face image to the dataset folder
        face_image = gray[y:y + h, x:x + w]
        face_filename = dataset_path + "/face_" + str(face_counter) + ".jpg"
        cv2.imwrite(face_filename, face_image)

        # Increment the face counter
        face_counter += 1

    # Display the frame
    cv2.imshow("Capture", frame)

    # Check for key press events
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
cap.release()
cv2.destroyAllWindows()
# Set the path to the dataset folder
dataset_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dataset"

# Function to load the training data
def load_training_data():
    faces = []
    labels = []
    label_ids = {}

    # Iterate over the subfolders in the dataset folder
    for root, dirs, files in os.walk(dataset_path):
        for dir_name in dirs:
            # Assign a label ID to each subfolder
            label_id = len(label_ids)
            label_ids[dir_name] = label_id

            # Get the path to the subfolder
            subfolder_path = os.path.join(root, dir_name)

            # Iterate over the image files in the subfolder
            for filename in os.listdir(subfolder_path):
                image_path = os.path.join(subfolder_path, filename)
                # Read the image file
                image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

                # Append the image and label to the training data
                faces.append(image)
                labels.append(label_id)

    return faces, labels, label_ids

# Load the training data
faces, labels, label_ids = load_training_data()

# Create the face recognition model
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# Train the face recognition model
face_recognizer.train(faces, np.array(labels))

# Save the trained model to a file
model_path = "face_model.yml"
face_recognizer.save(model_path)

messagebox.showinfo("Message", "Face model trained")








