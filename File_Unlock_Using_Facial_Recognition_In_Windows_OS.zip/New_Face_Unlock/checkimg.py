import cv2

image_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\Sample2\\man1.jpg"
original = cv2.imread(image_path)

if original is not None:
                gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    # Continue with further processing on the gray image
else:
                print("Failed to load the image:", image_path)
