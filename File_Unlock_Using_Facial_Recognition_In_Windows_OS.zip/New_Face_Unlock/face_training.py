import cv2
import os

# Set the name of the person
person_name = "authorized_user"

# Set the path to the dataset folder
dataset_path = "dataset/" + person_name

# Create the dataset folder if it doesn't exist
if not os.path.exists(dataset_path):
    os.makedirs(dataset_path)

# Initialize the webcam
cap = cv2.VideoCapture(0)

# Set the initial face counter
face_counter = 0

# Loop until the desired number of facial images is captured
while face_counter < 100:
    # Read the frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    # Iterate over the detected faces
    for (x, y, w, h) in faces:
        # Draw a rectangle around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Save the face image to the dataset folder
        face_image = gray[y:y + h, x:x + w]
        face_filename = dataset_path + "/face_" + str(face_counter) + ".jpg"
        cv2.imwrite(face_filename, face_image)

        # Increment the face counter
        face_counter += 1

    # Display the frame
    cv2.imshow("Capture", frame)

    # Check for key press events
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
cap.release()
cv2.destroyAllWindows()
