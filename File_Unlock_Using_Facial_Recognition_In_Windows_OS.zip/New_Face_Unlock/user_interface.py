import tkinter as tk
import subprocess
import sys

# Function to handle option selection
def handle_selection(option):
    try:
        if option == 1:
            subprocess.Popen([sys.executable, "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\new_input_unlock.py"], creationflags=subprocess.CREATE_NO_WINDOW)
        elif option == 2:
            subprocess.Popen([sys.executable, "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\newfacerecogv7.py"], creationflags=subprocess.CREATE_NO_WINDOW)
        elif option == 3:
            subprocess.Popen([sys.executable, "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\Trials\\newfacerecogv8.py"], creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            print("Invalid option!")
    except subprocess.CalledProcessError as e:
        print("An error occurred:", e.output.decode()) 
   
   
# Create the main window
window = tk.Tk()
window.title("FileCoffer")

# Create a label for the title
title_label = tk.Label(window, text="FileCoffer: Face Recognition", font=("Malgun Gothic", 24))
title_label.grid(row=0, column=0, pady=20, columnspan=2)

# Create option buttons
button_style = {"font": ("Malgun Gothic", 14), "width": 20, "height": 2, "bd": 0, "bg": "#2196f3", "fg": "white"}

option1_btn = tk.Button(window, text="File Unlock", command=lambda: handle_selection(1), **button_style)
option1_btn.grid(row=1, column=0, padx=30, pady=10, sticky="ew")

option2_btn = tk.Button(window, text="Deception Detection (Truth)", command=lambda: handle_selection(2), **button_style)
option2_btn.grid(row=2, column=0, padx=30, pady=10, sticky="ew")

option2_btn = tk.Button(window, text="Deception Detection (Lie)", command=lambda: handle_selection(3), **button_style)
option2_btn.grid(row=3, column=0, padx=30, pady=10, sticky="ew")

# Calculate the window size
button_frame_height = option1_btn.winfo_reqheight() + option2_btn.winfo_reqheight() + 3 * 10  # Button heights + padding
title_label_height = title_label.winfo_reqheight() + 2 * 20  # Title label height + padding
window_height = button_frame_height + title_label_height + 2 * 20  # Total window height
window_width = max(option1_btn.winfo_reqwidth(), option2_btn.winfo_reqwidth()) + 2 * 30  # Maximum button width + padding

# Set window dimensions and center it on the screen
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_coordinate = int((screen_width / 2) - (window_width / 2))
y_coordinate = int((screen_height / 2) - (window_height / 2))
window.geometry(f"{window_width+160}x{window_height+160}+{x_coordinate}+{y_coordinate}")

# Set a background color and configure padding
window.configure(bg="white")
window.configure(padx=20, pady=20)

# Run the main window loop
window.mainloop()




