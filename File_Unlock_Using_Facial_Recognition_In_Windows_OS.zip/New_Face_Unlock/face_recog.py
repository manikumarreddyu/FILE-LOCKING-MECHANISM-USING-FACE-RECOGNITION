import cv2
import os
import numpy as np

# Set the path to the dataset folder
dataset_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dataset"

# Function to load the training data
def load_training_data():
    faces = []
    labels = []
    label_ids = {}

    # Iterate over the subfolders in the dataset folder
    for root, dirs, files in os.walk(dataset_path):
        for dir_name in dirs:
            # Assign a label ID to each subfolder
            label_id = len(label_ids)
            label_ids[dir_name] = label_id

            # Get the path to the subfolder
            subfolder_path = os.path.join(root, dir_name)

            # Iterate over the image files in the subfolder
            for filename in os.listdir(subfolder_path):
                image_path = os.path.join(subfolder_path, filename)
                # Read the image file
                image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

                # Append the image and label to the training data
                faces.append(image)
                labels.append(label_id)

    return faces, labels, label_ids

# Load the training data
faces, labels, label_ids = load_training_data()

# Create the face recognition model
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# Train the face recognition model
face_recognizer.train(faces, np.array(labels))

# Save the trained model to a file
model_path = "face_model.yml"
face_recognizer.save(model_path)

print("Face recognition model trained and saved to", model_path)





