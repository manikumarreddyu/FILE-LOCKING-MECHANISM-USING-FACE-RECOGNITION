import tkinter as tk
from tkinter import messagebox

# Function to handle button click
def handle_button_click():
    user_input = entry.get()
    if user_input:
        messagebox.showinfo("User Input", f"You entered: {user_input}")
    else:
        messagebox.showerror("Error", "Please enter something.")

# Create the main window
window = tk.Tk()
window.title("User Input")

# Create a label
label = tk.Label(window, text="Enter something:")
label.pack(pady=10)

# Create an entry field
entry = tk.Entry(window, width=30)
entry.pack()

# Create a button
button = tk.Button(window, text="Submit", command=handle_button_click)
button.pack(pady=10)

# Run the main window loop
window.mainloop()

# Load the pre-trained face recognition model
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# Load the trained model from file
face_recognizer.read("face_model.yml")

# Set the path to the folder you want to lock
folder_path = "C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dummy"

# Initialize the webcam
cap = cv2.VideoCapture(0)

# Loop indefinitely
while True:
    # Read the frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    # Flag to check if an authorized user is detected
    authorized_user_detected = False

    # Iterate over the detected faces
    for (x, y, w, h) in faces:
        # Recognize the face
        face_image = gray[y:y + h, x:x + w]
        label_id, confidence = face_recognizer.predict(face_image)

        # Check if the face matches the authorized user
        if confidence < 70:
            authorized_user_detected = True
            break

    # If an authorized user is not detected, lock the folder
    if not authorized_user_detected:
        # Move the folder to a new location
        #locked_folder_path = folder_path + "_locked"
        #shutil.move(folder_path, locked_folder_path)

        # Print a message to indicate that the folder is locked
        # Set the path to the folder you want to lock
        folder_path = r"C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dummy"

        # Set the lock attribute for the folder (making it hidden and read-only)
        def lock_folder(path):
            try:
                # Set the folder as hidden
                attributes = ctypes.windll.kernel32.GetFileAttributesW(path)
                ctypes.windll.kernel32.SetFileAttributesW(path, attributes + 2)

                # Set the folder as read-only
                os.chmod(path, 0o400)

                print("Folder locked successfully!")
            except Exception as e:
                print("Failed to lock the folder:", e)

        # Call the function to lock the folder
        lock_folder(folder_path)

        # Break the loop and exit the program
        break
    else:
        # Set the path to the locked folder
        folder_path = r"C:\\Shivani\\MIT\\Notes\\Semester_4\\OS_Project\\New_Face_Unlock\\dummy"

        # Set the unlock attribute for the folder (removing hidden and read-only attributes)
        def unlock_folder(path):
            try:
                # Remove the hidden attribute from the folder
                attributes = ctypes.windll.kernel32.GetFileAttributesW(path)
                ctypes.windll.kernel32.SetFileAttributesW(path, attributes - 2)

                # Set the folder as writable
                os.chmod(path, 0o600)

                print("Folder unlocked successfully!")
                
            except Exception as e:
                print("Failed to unlock the folder:", e)     

        # Call the function to unlock the folder
        unlock_folder(folder_path)
    break

    # Display the frame
    cv2.imshow("Face Recognition", frame)

    # Check for key press events
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
cap.release()
cv2.destroyAllWindows()
